package ru.geekbrains.lesson3.task2;

/**
 * Фрилансер (работник с почасовой оплатой)
 * TODO: Доработать в рамках домашней работы
 */
public class Freelancer extends Employee {


    public Freelancer(String surName, String name, int salary, int labour_quantity, int age) {
        super(surName, name, salary, labour_quantity, age);
    }

    @Override
    public int calculateSalary() {
        return salary*labour_quantity;
    }

    @Override
    public String toString() {
        return String.format("%s %s; Фрилансер; Почасовая ставка: %d Отработано часов: %d Заработная плата: %d руб. Возраст: %d",
                surName, name, salary, labour_quantity, calculateSalary(), age);
    }
    
}
